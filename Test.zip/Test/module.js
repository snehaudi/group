var myobj={};

myobj.func1=function func1(){
    console.log('this is function 1');
}
myobj.func2=function func2(){
    console.log('this is function 2');
}
myobj.myvar=5;
module.exports=myobj;
